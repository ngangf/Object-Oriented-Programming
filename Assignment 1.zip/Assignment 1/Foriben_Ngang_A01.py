# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import sys
import random
import math

while True:
    try:
        s = int(input("Please enter the initial substrate concentration between 25 and 75: "))
        break
    except ValueError:
        print("The value entered is not an integer!")
        sys.exit()
if s >= 25 and s <= 75:
    if s % 5 == 0:
        print("The initial substrate concentration (s) = ", s,"gram per litre")
    else:
        print("The value entered is not divisible by 5!")
        sys.exit()
else:
    print("The value entered is not between 25 and 75!")
    sys.exit()

while True:
    try:    
        u = float(input("Please enter the maximum specific growth rate between 0.2 and 0.7: "))
        break
    except ValueError:
        print("The value entered is invalid!")
        sys.exit()
if u > 0.2 and u < 0.7:
    print("The maximum specific growth rate (u) = ", u,"per hour", "\n")
else:
    print("The value entered is not between 0.2 and 0.7")
    sys.exit()
    
k = random.randint(2,7)
print("The saturation constant (k) = ", k,"hour per litre", "\n")

d = u * (1 - math.sqrt(k / (k + s)))

print("The maximum dilution rate = ", format(d, ".2f"),"per hour", "\n")

if 0.35 < d < 0.45:
    print("Kinetic parameters are acceptable")
else:
    print("Kinetic parameters are not acceptable")