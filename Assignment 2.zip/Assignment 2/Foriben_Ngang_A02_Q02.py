# -*- coding: utf-8 -*-
"""
Created on Sat Mar 20 23:01:22 2021

@author: PGUser
"""

import math
import sys

def main():
    x = []
    infile = open('A2_input.txt', 'r')
   
    for list in infile:
        x.append(list)
    
    y = []
    
    for l in x:
        y.append(l.split())
        
    infile.close()
    
    option = input('Please enter an option from the range [1,3]: ')
    
    if option == "1":
        value = float(input("Please enter the Patient # from 1 to 5: "))
        while value < 1 or value > 5:
            value = float(input("Please enter the Patient # from 1 to 5: "))
        
        D = analyzeData(y,value)
        
        print('The number of data for patient #', format(D[0], ".0f"), 'is', format(D[1], ".0f"))
        print('The average of the patient data is: ', format(D[2], ".1f"), ' ', format(D[3], ".1f"), ' ', format(D[4], ".1f"))
        print('The half-life is', format(D[5], ".1f"))
        
    elif option == "2":
        p1 = float(input("Please enter the first patient's # from 1 to 5: "))
        while p1 < 1 or p1 > 5:
            p1 = float(input("Please enter the first patient's # from 1 to 5: "))
            
        D = analyzeData(y,p1)
        h1 = D[5]
        
        print('The number of data for patient #', format(D[0], ".0f"), 'is', format(D[1], ".0f"))
        print('The average of the patient data is: ', format(D[2], ".1f"), ' ', format(D[3], ".1f"), ' ', format(D[4], ".1f"))
        print('The half-life is', format(D[5], ".1f"))
        
        
        p2 = float(input("Please enter the second patient's # from 1 to 5: "))
        while p2 < 1 or p2 > 5:
            p2 = float(input("Please enter the second patient's # from 1 to 5: "))
            
        D = analyzeData(y,p2)
        h2 = D[5]
        
        print('The number of data for patient #', format(D[0], ".0f"), 'is', format(D[1], ".0f"))
        print('The average of the patient data is: ', format(D[2], ".1f"), ' ', format(D[3], ".1f"), ' ', format(D[4], ".1f"))
        print('The half-life is', format(D[5], ".1f"))
        
        
        p3 = float(input("Please enter the third patient's # from 1 to 5: "))
        while p3 < 1 or p3 > 5:
            p3 = float(input("Please enter the third patient's # from 1 to 5: "))
            
        D = analyzeData(y,p3)
        h3 = D[5]
        
        print('The number of data for patient #', format(D[0], ".0f"), 'is', format(D[1], ".0f"))
        print('The average of the patient data is: ', format(D[2], ".1f"), ' ', format(D[3], ".1f"), ' ', format(D[4], ".1f"))
        print('The half-life is', format(D[5], ".1f"))
        
        h = (h1 + h2 + h3)/3
        
        print("\n",'The average half-life of the three patients is', format(h, ".1f"), "\n") 
        
        C = longest(format(h1, ".1f"),format(h2, ".1f"),format(h3, ".1f"))
        print("The two longest average half-life of the three patients are", C[0], 'and', C[1])
        
        
    elif option == "3":
        sys.exit()
            
            
def analyzeData(y,value):
    total = 0
    co_total = 0
    ct_total = 0
    t_total = 0
    for i in range(len(y)):
        if int(y[i][0]) == value:
            total = total + 1
            co_total = co_total + int(y[i][1])
            ct_total = ct_total + int(y[i][2])
            t_total = t_total + float(y[i][3])
    co = co_total/total
    ct = ct_total/total
    t = t_total/total
    
    hl = halfLife(co,ct,t)
    return [value,total,co,ct,t,hl]

def halfLife(a,b,c):
    hl = -0.95 * c * math.log(2) / (math.log(b/a))
    return hl

def longest(l,m,n):
    if l > m:
        if m > n:
            return [l,m]
        else:
            return [l,n]
    elif m > l:
        if l > n:
            return [m,l]
        else:
            return [m,n]
    elif n > m:
        if m > l:
            return [n,m]
        else:
            return [n,l]
        
main()  