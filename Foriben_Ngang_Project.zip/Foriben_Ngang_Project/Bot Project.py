# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 13:25:10 2021

@author: PGUser
"""

import math

import random

import ps2_visualize

class Position(object):
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        
    def getX(self):
        return self.x
    
    def getY(self):
        return self.y
    
    def getNewPosition(self, angle, speed):
        old_x, old_y = self.getX(), self.getY()
        angle = float(angle)
        delta_y = speed * math.cos(math.radians(angle))
        delta_x = speed * math.sin(math.radians(angle))
        new_x = old_x + delta_x
        new_y = old_y + delta_y
        return Position(new_x, new_y)

    def __str__(self):  
        return "(%0.2f, %0.2f)" % (self.x, self.y)

class RectangularRoom(object):
    
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.cleaned_tiles = []

    def cleanTileAtPosition(self, pos):
        point = (int(pos.getX()), int(pos.getY()))
        if point not in self.cleaned_tiles:
            self.cleaned_tiles.append(point)

    def isTileCleaned(self, m, n):
        self.m = m
        self.n = n
        tile = (self.m, self.n)
        if tile in self.cleaned_tiles:
            return True
        else:
            return False
        
    def getNumTiles(self):
        return self.width * self.height
    
    def getNumCleanedTiles(self):
        return len(self.cleaned_tiles)
    
    def getRandomPosition(self):
        randx = random.uniform(0, self.width)
        randy = random.uniform(0, self.height)
        return Position(randx, randy)
    
    def isPositionInRoom(self, pos):
        if pos.x >= 0 and pos.x < self.width and pos.y >= 0 and pos.y < self.height:
            return True
        else:
            return False
        
class Robot(object):

    def __init__(self, room, speed):
        self.room = room
        self.speed = speed
        self.position = room.getRandomPosition()
        self.direction = random.randint(0, 359)
        
    def getRobotPosition(self):
        return self.position
    
    def getRobotDirection(self):
        return self.direction
    
    def setRobotPosition(self, position):
        self.position = position
        
    def setRobotDirection(self, direction):
        self.direction = direction

class StandardRobot(Robot):   
    
    def updatePositionAndClean(self):
        next_position = self.getRobotPosition().getNewPosition(self.getRobotDirection(), self.speed)
        if self.room.isPositionInRoom(next_position) == False:
            self.setRobotDirection(random.randint(0, 359))
        else:
            self.setRobotPosition(next_position)            
            self.room.cleanTileAtPosition(next_position)
            
def runSimulation(num_robots, speed, width, height, min_coverage, num_trials, robot_type):
    results = []
    for i in range(num_trials):
        anim = ps2_visualize.RobotVisualization(num_robots, width, height)
        num_steps = 0
        # Instantiate a new room
        room = RectangularRoom(width, height)
        # Instantiate the robots
        robots = [robot_type(room, speed) for j in range(num_robots)]
        while (room.getNumCleanedTiles()/room.getNumTiles()) < min_coverage:
            num_steps += 1
            anim.update(room, robots)
            for k in robots:
                k.updatePositionAndClean()
            if (room.getNumCleanedTiles()/room.getNumTiles()) >= min_coverage:
                results.append(num_steps)
                anim.done()
            else:
                continue
    return sum(results)/len(results)

print(runSimulation(3, 1.0, 15, 10, 1.0, 30, StandardRobot))

