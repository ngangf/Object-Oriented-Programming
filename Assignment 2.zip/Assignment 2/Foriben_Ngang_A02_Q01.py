# -*- coding: utf-8 -*-
"""
Created on Sat Mar 20 17:49:14 2021

@author: PGUser
"""

def main():
    V = inputValues()
    t = V[0]
    g = V[1]
    D = calculateDistance(t,g)
    displayResults(t,g,D)
    
def inputValues():
    a = float(input('Please enter the time the object takes to fall between 0 and 45: '))
    while a < 0 or a > 45:
        a = float(input('Please enter the time the object takes to fall between 0 and 45: '))
    b = float(input('Please enter the gravity measured between 0.1 and 10.2: '))
    while b < 0.1 or b > 10.2:
         b = float(input('Please enter the gravity measured between 0.1 and 10.2: '))
    
    calculateDistance(a,b)
    return [a,b]
    
def calculateDistance(x,y):
    c = 0.5 * y * x ** 2
    return c
    
def displayResults(d,e,f):
    print("\n",'The time is ', format(d, ".2f"),"sec", "\n")
    print("\n",'The gravity is ', format(e, ".2f"),"m/sec^2", "\n")
    print("\n",'The distance is', format(f, ".2f"),"m", "\n") 
    
main()